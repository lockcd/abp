﻿namespace Volo.Blogging.Files
{
    public class FileUploadOutputDto
    {
        public string Name { get; set; }

        public string WebUrl { get; set; }
    }
}