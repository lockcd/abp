﻿using Volo.Blogging.EntityFrameworkCore;
using Volo.Blogging.Tagging;

namespace Volo.Blogging
{
    public class TagRepository_Tests : TagRepository_Tests<BloggingEntityFrameworkCoreTestModule>
    {
    }
}