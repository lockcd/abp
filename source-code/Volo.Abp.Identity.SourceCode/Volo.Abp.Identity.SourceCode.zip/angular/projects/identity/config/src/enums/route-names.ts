export const enum eIdentityRouteNames {
  IdentityManagement = 'AbpIdentity::Menu:IdentityManagement',
  Roles = 'AbpIdentity::Roles',
  Users = 'AbpIdentity::Users',
}
