// This file is part of IdentityUserIntegrationClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Abp.Identity.Integration;

public partial class IdentityUserIntegrationClientProxy
{
}
