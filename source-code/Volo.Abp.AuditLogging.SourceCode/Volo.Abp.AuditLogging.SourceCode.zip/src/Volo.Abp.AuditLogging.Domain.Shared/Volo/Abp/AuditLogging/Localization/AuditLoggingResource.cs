﻿using Volo.Abp.Localization;

namespace Volo.Abp.AuditLogging.Localization;

[LocalizationResourceName("AbpAuditLogging")]
public class AuditLoggingResource
{
}
