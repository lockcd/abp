namespace Volo.Abp.AuditLogging;

public static class AuditLogExcelFileConsts
{
    /// <summary>
    /// Default value: 256
    /// </summary>
    public static int MaxFileNameLength { get; set; } = 256;
}
