namespace Volo.Abp.AuditLogging.EntityFrameworkCore;

public class AuditLogEntityTypeFullNameConverter_Tests : AuditLogEntityTypeFullNameConverter_Tests<AbpAuditLoggingEntityFrameworkCoreTestModule>
{

}
