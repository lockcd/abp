namespace Volo.Abp.FeatureManagement.Blazor.Components.FeatureSettingGroup;

public class FeatureSettingViewModel
{
    public bool HasManageHostFeaturesPermission { get; set; }
}