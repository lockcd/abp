﻿using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace DemoApp.Pages;

public class IndexModel : AbpPageModel
{
    
}