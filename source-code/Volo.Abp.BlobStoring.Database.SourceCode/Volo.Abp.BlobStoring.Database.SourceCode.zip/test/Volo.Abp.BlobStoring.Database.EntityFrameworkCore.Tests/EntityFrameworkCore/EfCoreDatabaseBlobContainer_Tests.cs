﻿namespace Volo.Abp.BlobStoring.Database.EntityFrameworkCore;

public class EfCoreDatabaseBlobContainer_Tests : DatabaseBlobContainer_Tests<BlobStoringDatabaseEntityFrameworkCoreTestModule>
{

}
