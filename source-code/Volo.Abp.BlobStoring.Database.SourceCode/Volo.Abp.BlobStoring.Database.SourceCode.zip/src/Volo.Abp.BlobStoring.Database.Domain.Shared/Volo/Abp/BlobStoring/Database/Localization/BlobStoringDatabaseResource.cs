﻿using Volo.Abp.Localization;

namespace Volo.Abp.BlobStoring.Database.Localization;

[LocalizationResourceName("BlobStoringDatabase")]
public class BlobStoringDatabaseResource
{

}
