// This file is part of EmailSettingsClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Abp.SettingManagement;

public partial class EmailSettingsClientProxy
{
}
