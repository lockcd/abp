export const enum SettingManagementPolicyNames {
  Emailing = 'SettingManagement.Emailing',
}
