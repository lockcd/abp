using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Volo.Abp.SettingManagement.DemoApp.Pages;

public class IndexModel : PageModel
{
    public void OnGet()
    {
    }
}
