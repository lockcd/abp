﻿using System;
using Volo.Abp.Data;
using Volo.Abp.Modularity;
using Volo.Abp.Uow;

namespace Volo.Abp.PermissionManagement.MongoDB;

[DependsOn(
    typeof(AbpPermissionManagementMongoDbModule),
    typeof(AbpPermissionManagementTestBaseModule))]
public class AbpPermissionManagementMongoDbTestModule : AbpModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<AbpDbConnectionOptions>(options =>
        {
            options.ConnectionStrings.Default = MongoDbFixture.GetRandomConnectionString();
        });
    }
}
