import { NgModule } from '@angular/core';
import { PermissionManagementComponent } from './components';

@NgModule({
  declarations: [],
  imports: [PermissionManagementComponent],
  exports: [PermissionManagementComponent],
})
export class PermissionManagementModule {}
