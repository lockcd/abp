﻿using Volo.Abp.Localization;

namespace Volo.Abp.Account.Localization;

[LocalizationResourceName("AbpAccount")]
public class AccountResource
{

}
