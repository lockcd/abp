﻿namespace Volo.Abp.Account.Emailing.Templates;

public static class AccountEmailTemplates
{
    public const string PasswordResetLink = "Abp.Account.PasswordResetLink";
}
