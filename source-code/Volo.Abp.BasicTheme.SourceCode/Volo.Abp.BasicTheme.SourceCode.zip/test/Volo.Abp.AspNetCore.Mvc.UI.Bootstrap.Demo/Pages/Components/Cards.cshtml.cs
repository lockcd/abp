﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.Demo.Pages.Components;

public class CardsModel : PageModel
{
    public void OnGet()
    {

    }
}
