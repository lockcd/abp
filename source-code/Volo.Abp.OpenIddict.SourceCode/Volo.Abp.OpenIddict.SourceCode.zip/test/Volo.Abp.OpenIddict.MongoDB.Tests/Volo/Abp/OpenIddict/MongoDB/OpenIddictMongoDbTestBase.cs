﻿namespace Volo.Abp.OpenIddict.MongoDB;

public abstract class OpenIddictMongoDbTestBase : OpenIddictTestBase<OpenIddictMongoDbTestModule>
{

}
