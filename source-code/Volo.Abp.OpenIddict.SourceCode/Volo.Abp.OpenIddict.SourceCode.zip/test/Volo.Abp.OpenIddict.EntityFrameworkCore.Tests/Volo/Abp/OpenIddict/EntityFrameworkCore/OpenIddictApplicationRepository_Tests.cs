﻿namespace Volo.Abp.OpenIddict.EntityFrameworkCore;

public class OpenIddictApplicationRepository_Tests : OpenIddictApplicationRepository_Tests<OpenIddictEntityFrameworkCoreTestModule>
{
    
}