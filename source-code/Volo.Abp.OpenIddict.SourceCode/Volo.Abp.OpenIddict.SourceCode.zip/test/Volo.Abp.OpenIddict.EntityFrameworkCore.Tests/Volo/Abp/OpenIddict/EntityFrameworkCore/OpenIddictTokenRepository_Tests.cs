﻿namespace Volo.Abp.OpenIddict.EntityFrameworkCore;

public class OpenIddictTokenRepository_Tests : OpenIddictTokenRepository_Tests<OpenIddictEntityFrameworkCoreTestModule>
{
    
}