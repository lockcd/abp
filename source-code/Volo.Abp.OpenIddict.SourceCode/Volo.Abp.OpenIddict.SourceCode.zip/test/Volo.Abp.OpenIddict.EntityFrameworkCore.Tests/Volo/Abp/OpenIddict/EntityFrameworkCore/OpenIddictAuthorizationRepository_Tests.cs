﻿namespace Volo.Abp.OpenIddict.EntityFrameworkCore;

public class OpenIddictAuthorizationRepository_Tests : OpenIddictAuthorizationRepository_Tests<OpenIddictEntityFrameworkCoreTestModule>
{
    
}