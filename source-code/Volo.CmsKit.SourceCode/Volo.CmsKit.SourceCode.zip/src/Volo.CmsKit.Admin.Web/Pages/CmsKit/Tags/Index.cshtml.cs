﻿using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace Volo.CmsKit.Admin.Web.Pages.CmsKit.Tags;

public class IndexModel : CmsKitAdminPageModel
{
}
