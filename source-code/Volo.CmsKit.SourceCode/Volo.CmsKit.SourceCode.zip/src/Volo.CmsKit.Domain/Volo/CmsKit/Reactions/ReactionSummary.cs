﻿namespace Volo.CmsKit.Reactions;

public class ReactionSummary
{
    public ReactionDefinition Reaction { get; set; }

    public int Count { get; set; }
}
