﻿namespace Volo.CmsKit.Ratings;

public class RatingWithStarCountQueryResultItem
{
    public short StarCount { get; set; }

    public int Count { get; set; }
}
