﻿using System;

namespace Volo.CmsKit.Contents;

[Serializable]
public class WidgetDetailDto
{
    public string Name { get; set; }
    public string EditorComponentName { get; set; }
}
