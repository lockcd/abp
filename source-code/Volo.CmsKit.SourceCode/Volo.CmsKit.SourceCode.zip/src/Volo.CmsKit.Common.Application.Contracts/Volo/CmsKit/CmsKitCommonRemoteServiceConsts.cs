﻿namespace Volo.CmsKit;

public class CmsKitCommonRemoteServiceConsts
{
    public const string RemoteServiceName = "CmsKitCommon";

    public const string ModuleName = "cms-kit-common";
}
