﻿namespace Volo.CmsKit.MultiTenancy
{
    public static class MultiTenancyConsts
    {
        /* Enable/disable multi-tenancy in a single point
         * to test your module with multi-tenancy.
         */
        public const bool IsEnabled = false;
    }
}
