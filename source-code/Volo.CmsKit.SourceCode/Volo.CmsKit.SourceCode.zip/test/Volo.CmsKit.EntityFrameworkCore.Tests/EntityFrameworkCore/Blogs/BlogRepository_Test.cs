﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.CmsKit.Blogs;

namespace Volo.CmsKit.EntityFrameworkCore.Blogs;

public class BlogRepository_Test : BlogRepository_Test<CmsKitEntityFrameworkCoreTestModule>
{

}
