﻿using Volo.CmsKit.MarkedItems;

namespace Volo.CmsKit.EntityFrameworkCore.MarkedItems;
public class UserMarkedItemRepository_Tests : UserMarkedItemRepository_Tests<CmsKitEntityFrameworkCoreTestModule>
{
}
