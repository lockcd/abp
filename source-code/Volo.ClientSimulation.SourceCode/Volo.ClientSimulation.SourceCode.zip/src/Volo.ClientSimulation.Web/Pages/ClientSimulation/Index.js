(function ($) {
    $(function () {
        SimulationArea.init($('#SimulationArea'));
    });
})(jQuery);
