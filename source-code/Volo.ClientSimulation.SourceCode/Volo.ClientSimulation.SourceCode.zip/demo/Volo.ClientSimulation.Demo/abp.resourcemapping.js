module.exports = {
    aliases: {
        
    },
    mappings: {
        
    }
}