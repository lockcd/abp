﻿namespace Volo.Abp.IdentityServer.Clients;

public class ClientIdPRestrictionConsts
{
    /// <summary>
    /// Default value: 200
    /// </summary>
    public static int ProviderMaxLength { get; set; } = 200;
}
