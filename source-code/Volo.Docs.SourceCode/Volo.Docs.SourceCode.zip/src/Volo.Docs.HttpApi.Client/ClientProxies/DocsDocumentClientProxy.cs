// This file is part of DocsDocumentClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Docs.Documents;

public partial class DocsDocumentClientProxy
{
}
