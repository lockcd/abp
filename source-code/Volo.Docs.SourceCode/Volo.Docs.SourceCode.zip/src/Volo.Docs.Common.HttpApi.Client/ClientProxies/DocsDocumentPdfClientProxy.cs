// This file is part of DocsDocumentPdfClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Docs.Documents;

public partial class DocsDocumentPdfClientProxy
{
}
