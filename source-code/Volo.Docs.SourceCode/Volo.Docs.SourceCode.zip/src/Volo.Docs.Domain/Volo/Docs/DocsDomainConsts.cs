﻿namespace Volo.Docs
{
    public class DocsDomainConsts
    {
        public static string LanguageConfigFileName = "docs-langs.json";
        public static string PdfDocumentToHtmlConverterPrefix = "pdf-";
    }
}