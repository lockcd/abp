﻿namespace Volo.Docs
{
    public class DocsDomainConsts
    {
        public static string LanguageConfigFileName = "docs-langs.json";
    }
}