using Volo.Abp.BlobStoring;

namespace Volo.Docs.Projects.Pdf;

[BlobContainerName("docs-document-pdf")]
public class DocsProjectPdfContainer
{
    
}