﻿using AutoMapper;

namespace Volo.Docs
{
    public class DocsWebAutoMapperProfile : Profile
    {
        public DocsWebAutoMapperProfile()
        {
        }
    }
}
