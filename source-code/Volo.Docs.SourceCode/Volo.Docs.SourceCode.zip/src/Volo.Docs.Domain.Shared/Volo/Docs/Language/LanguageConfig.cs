﻿using System.Collections.Generic;

namespace Volo.Docs.Documents
{
    public class LanguageConfig
    {
        public List<LanguageConfigElement> Languages { get; set; }
    }
}
