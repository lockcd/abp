﻿namespace Volo.Docs.Documents.Rendering
{
    public class DocumentPartialTemplateContent
    {
        public string Path { get; set; }

        public string Content { get; set; }
    }
}