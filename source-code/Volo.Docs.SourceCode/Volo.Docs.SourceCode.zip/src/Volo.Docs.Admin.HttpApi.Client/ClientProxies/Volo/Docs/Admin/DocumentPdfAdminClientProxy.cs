// This file is part of DocumentPdfAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Docs.Admin;

public partial class DocumentPdfAdminClientProxy
{
}
