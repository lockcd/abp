﻿namespace Volo.Docs
{
    public static class DocsRemoteServiceConsts
    {
        public const string RemoteServiceName = "AbpDocs";

        public const string ModuleName = "docs";
    }
}
