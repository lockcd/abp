﻿namespace Volo.Docs.Common
{
    public static class DocsCommonRemoteServiceConsts
    {
        public const string RemoteServiceName = "AbpDocsCommon";

        public const string ModuleName = "docs-common";
    }
}
