﻿namespace Volo.Docs.Common.Projects
{
    public class VersionInfoDto
    {
        public string DisplayName { get; set; }

        public string Name { get; set; }
    }
}
