﻿namespace Volo.Docs.Admin
{
    public static class DocsAdminRemoteServiceConsts
    {
        public const string RemoteServiceName = "AbpDocsAdmin";

        public const string ModuleName = "docs-admin";
    }
}
