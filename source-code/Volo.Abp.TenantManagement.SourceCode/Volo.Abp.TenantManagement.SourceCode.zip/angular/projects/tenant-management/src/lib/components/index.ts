export * from './tenants/tenants.component';
